package com.example.newsappshubh;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements CategoryRVAdapter.CategorClickInterface{
//f5218972da654fc1b0839b403a8c2f3f
    private RecyclerView newsRV,categoryRV;
    private ProgressBar loadingPB;
    private ArrayList<Articles> articlesArrayList;
    private ArrayList<CategoryRVModel> categoryRVModelArrayList;
    private CategoryRVAdapter categoryRVAdapter;
    private NewsRVAdapter newsRVAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        newsRV= findViewById(R.id.idRVNews);
        categoryRV = findViewById(R.id.idRVCategories);
        loadingPB = findViewById(R.id.idPBLLoding);
        articlesArrayList = new ArrayList<>();
        categoryRVModelArrayList = new ArrayList<>();
        newsRVAdapter = new NewsRVAdapter(articlesArrayList,this);
        categoryRVAdapter = new CategoryRVAdapter(categoryRVModelArrayList,this,this::onCatogeryClick);
        newsRV.setLayoutManager(new LinearLayoutManager(this));
        newsRV.setAdapter(newsRVAdapter);
        categoryRV.setAdapter(categoryRVAdapter);
        getCategories();

    }
    private void getCategories(){
        categoryRVModelArrayList.add(new CategoryRVModel("All","https://images.unsplash.com/photo-1575550959106-5a7defe28b56?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8d2lsZGxpZmV8ZW58MHx8MHx8&w=1000&q=80"));
        categoryRVModelArrayList.add(new CategoryRVModel("Technology","https://wallpaperaccess.com/full/2018953.jpg"));
        categoryRVModelArrayList.add(new CategoryRVModel("Science","https://res.cloudinary.com/jerrick/image/upload/f_jpg,fl_progressive,q_auto,w_1024/d4mmmwmkthezbqmwtvxy.jpg"));
        categoryRVModelArrayList.add(new CategoryRVModel("Sports","https://img.freepik.com/free-photo/sports-tools_53876-138077.jpg?w=2000"));
        categoryRVModelArrayList.add(new CategoryRVModel("General","https://www.shutterstock.com/image-illustration/3d-illustration-tv-studio-news-260nw-1987971701.jpg"));
        categoryRVModelArrayList.add(new CategoryRVModel("Bussiness","https://static.vecteezy.com/system/resources/previews/008/015/895/large_2x/businessman-planning-to-invest-in-stock-market-man-touching-success-goals-icon-on-virtual-screen-stock-graph-is-rising-economy-is-recovering-stock-trading-bussiness-start-up-business-success-free-photo.jpg"));
        categoryRVModelArrayList.add(new CategoryRVModel("Entertainment","https://images.unsplash.com/photo-1603190287605-e6ade32fa852?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8ZW50ZXJ0YWlubWVudHxlbnwwfHwwfHw%3D&w=1000&q=80"));
        categoryRVModelArrayList.add(new CategoryRVModel("Health","https://cdn.portfolio.hu/articles/images-xl/k/o/r/koronavirus-478304.jpg"));
        categoryRVAdapter.notifyDataSetChanged();
        getNews("All");
        newsRVAdapter.notifyDataSetChanged();

    }
    private void getNews( String category){
        loadingPB.setVisibility(View.VISIBLE);
        articlesArrayList.clear();
        String categoryURL = "https://newsapi.org/v2/top-headlines?country=hu&category="+category+"&apiKey=f5218972da654fc1b0839b403a8c2f3f";
        String url = "https://newsapi.org/v2/top-headlines?country=hu&apiKey=f5218972da654fc1b0839b403a8c2f3f";
        String BaseUrl ="https://newsapi.org/";
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BaseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RetrofitApi retrofitApi = retrofit.create(RetrofitApi.class);
        Call<NewsModel>call;
        if(category.equals("All")){
            call = retrofitApi.getAllNews(url);

        }else{
            call = retrofitApi.getNewsByCategory(categoryURL);
        }
        call.enqueue(new Callback<NewsModel>() {
            @Override
            public void onResponse(Call<NewsModel> call, Response<NewsModel> response) {
                NewsModel newsModel= response.body();
                loadingPB.setVisibility(View.GONE);
                ArrayList<Articles> articles = newsModel.getArticles();
                for(int i=0; i< articles.size();i++){
                    articlesArrayList.add(new Articles(articles.get(i).getTitle(),articles.get(i).getDescription(),articles.get(i).getUrlToImage(),
                            articles.get(i).getUrl(),articles.get(i).getContent()));

                }
                newsRVAdapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<NewsModel> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Sorry ! it didn't Work again ", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onCatogeryClick(int position) {
        String category = categoryRVModelArrayList.get(position).getCategory();
        getNews(category);

    }
}